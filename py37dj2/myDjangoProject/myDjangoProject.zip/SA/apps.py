from django.apps import AppConfig


class SaConfig(AppConfig):
    name = 'SA'
